    <!-- Footer Strat -->
    <footer>
        <div class="social">

            <div class="link">
                <a href="#home">Home</a>
                <a href="#about">About</a>
                <a href="#produts">Products</a>
                <a href="#review">Review</a>
                <a href="#contactme">Contactme</a>
            </div>

            <div class="credit">
                <p>Created by <a href="https://www.instagram.com/nrfatiiimhhh?igsh=MTg3cHUyenBhNWpmNw==">nrftimhh</a>. | &copy; 2023.</p>
            </div>
        </div>
    </footer>
    <!-- Footer End -->